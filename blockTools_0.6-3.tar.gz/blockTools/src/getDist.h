double cmahal(double *x1, double *capX, int *n, double *x2);
double * allmahal(int *ncol, int *nrow, int n, double *data, double *vcovi, double *vec);
double * cleanUp(int l2, int *l1names, int valid, double *validvar, double validlb, double validub, int n, double *vec);
