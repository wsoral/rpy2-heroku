infmean <- function(x){
  return(mean(is.infinite(x)))
}
